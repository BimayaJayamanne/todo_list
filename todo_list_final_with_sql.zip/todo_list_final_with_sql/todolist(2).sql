-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2023 at 09:12 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `todolist`
--

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE `attachments` (
  `id` int(11) NOT NULL,
  `attachment` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `start_date` datetime NOT NULL DEFAULT current_timestamp(),
  `end_date` datetime NOT NULL,
  `is_important` tinyint(1) NOT NULL,
  `is_completed` tinyint(1) NOT NULL,
  `notes` text NOT NULL,
  `task_list` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `name`, `start_date`, `end_date`, `is_important`, `is_completed`, `notes`, `task_list`) VALUES
(55, 'Play with Amelia', '2023-12-02 21:40:09', '0000-00-00 00:00:00', 0, 0, '            ', 37),
(59, 'Buy bread', '2023-12-03 03:51:35', '2023-12-09 00:00:00', 1, 1, '            ', 40),
(60, 'Make shortnotes', '2023-12-03 06:07:43', '2023-12-09 00:00:00', 1, 0, '            ', 42),
(64, 'Buy yoghurt', '2023-12-03 06:41:29', '2023-12-07 00:00:00', 0, 0, '            ', 40),
(66, 'Clean the garden', '2023-12-03 09:00:09', '2023-12-09 00:00:00', 0, 0, '            ', 39),
(68, 'AG meeting', '2023-12-03 09:10:37', '2023-12-12 00:00:00', 1, 0, '            ', 45);

-- --------------------------------------------------------

--
-- Table structure for table `tasks_lists`
--

CREATE TABLE `tasks_lists` (
  `tasks_list_name` varchar(40) NOT NULL,
  `task_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks_lists`
--

INSERT INTO `tasks_lists` (`tasks_list_name`, `task_id`) VALUES
('Clean', 39),
('Grocery', 40),
('Study', 42),
('Work', 45);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks_lists`
--
ALTER TABLE `tasks_lists`
  ADD PRIMARY KEY (`task_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `tasks_lists`
--
ALTER TABLE `tasks_lists`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
