<?php
$conn = new mysqli("localhost", "myuser", "", "todolist");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Description</title>
    <link rel="stylesheet" href="todo.css" type="text/css" />
</head>

<body>

    <div class="task_desc">
        <form method="post" action="task_desc.php">
        <div class="desc_header">
        <h3 class="desc_title">Task Description</h3>
    </div>

            <div class="form-group">
                <label for="task_list_name">Task Type  :</label>
                <select name="selected_list">
                    <?php
                    $result = $conn->query("SELECT * FROM tasks_lists;");
                    foreach ($result as $row) {
                    ?>
                        <option value="<?= $row['task_id'] ?>">
                            <?= $row['tasks_list_name'] ?>
                        </option>
                    <?php
                    }
                    ?>
                </select>

   

            </div>

            <div class="form-group">
                <label for="name">Task   : </label>
                <input type="text" id="task_name" name="name" aria-label="task name" required minlength="1" maxlength="50" />
            </div>

            <div class="form-group">
                <label for="important">Important   :</label>
                <input type="checkbox" id="important" name="important" />
            </div>
            <div class="form-group">
                <label for="start">Added date   : </label>
                <input type="date" id="start_date" name="start" value="<?= date('Y-m-d') ?>" min="2023-11-29" max="2030-12-31" />
            </div>
            <div class="form-group">
                <label for="due">Due date   : </label>
                <input type="date" id="end" name="task_end" value='$date' min="2023-11-29" max="2030-12-31" />
            </div>
            <label for="notes">Notes   :   </label>
            <textarea id="notes" name="notes" rows="5" cols="60">
            </textarea>

            <label for="image">Add an image   :   </label>
            <input type="file" id="image" name="image" accept="image/png, image/jpeg" />

            <input type="submit" value="Add Task" class="submitfield" id="submitfield">
        </form>
    </div </body>

</html>

<?php if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isImportant = false;
    if (isset($_POST['important'])) {
        $isImportant = isset($_POST['important']);
    }
    $date = date('Y-m-d H:i:s');

    $query = $conn->prepare("INSERT INTO `tasks` (`name`, `start_date`, `end_date`, `is_important`, `is_completed`, `notes`,`task_list`) VALUES ( ?,?,?,?,0,?,?); ");
    $query->bind_param("sssiss", $_POST['name'], $date, $_POST['task_end'], $isImportant, $_POST["notes"], $_POST['selected_list']);
    $query->execute();
    $result = $query->get_result();
    echo '<script> window.location.href = "todo.php"</script>';
} ?>