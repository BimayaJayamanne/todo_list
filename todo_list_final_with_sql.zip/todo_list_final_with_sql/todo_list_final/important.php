<?php
$conn = new mysqli("localhost", "myuser", "", "todolist");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Important</title>
    <link rel="stylesheet" href="todo.css" type="text/css" />

</head>
<body>
<div class="important">
<button id="showImportantBtn">Click to see Important tasks</button>

<table id="importantTasksList" style="display:none;">
    <thead>
        <tr>
            <th>Name</th>
            <th>Due Date</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $result = $conn->query("SELECT * FROM `tasks` WHERE `is_important` = 1;");
        foreach ($result as $row) {
        ?>
            <tr class="important-task">
                <td class="task-name"><?php echo $row['name']; ?></td>
                <td class="task-date"><?php echo $row['end_date']; ?></td>
            </tr>
        <?php
        }
        ?>
    </tbody>
</table>
                <script>
                document.getElementById('showImportantBtn').addEventListener('click', function() {
                    const importantTasksList = document.getElementById('importantTasksList');
                    importantTasksList.style.display = importantTasksList.style.display === 'none' ? 'block' : 'none';
                });
            </script>
    </div>
</body>
</html>