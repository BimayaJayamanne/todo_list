<?php
$conn = new mysqli("localhost", "myuser", "", "todolist");
$mode = 'list';
if (isset($_REQUEST['mode']))
    $mode = $_REQUEST['mode'];

$task_list = 1;
if (isset($_REQUEST['list'])) {
    $task_list = $_REQUEST['list'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ToDo_List</title>
    <link rel="stylesheet" href="todo.css" type="text/css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>

<body>
    <div class="header">
        <h1 class="title">My ToDo List</h1>
    </div>

    <div class="task_Lists">
        <h2 class="task_lists_title"> Task Lists </h2>
        <ul class="tasklists">
            <!-- <div class="myday">
                <li>My Day </li?>
            </div> -->

          
            <div class="important">
                <button id="showImportantBtn"><a href="important.php">Important</a></button>
            </div>


            <div class="list">
                <?php
                $result = $conn->query("SELECT * FROM tasks_lists;");
                foreach ($result as $row) {
                ?>
                    <div class="taskslist">
                        <h4><a <?php if ($task_list === $row['task_id']) echo 'class="selected"' ?> href="?list=<?= $row['task_id'] ?>"> <?php echo $row['tasks_list_name'] ?> </a></h4>
                    </div>
                <?php
                }
                ?>
            </div>
        </ul>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_REQUEST['mode']) && $_REQUEST['mode'] == 'add_new_list') {
            if (isset($_POST['list_name'])) {
                $newListName = htmlspecialchars($_POST['list_name'], ENT_QUOTES, 'UTF-8');


                $query = $conn->prepare("INSERT INTO tasks_lists (tasks_list_name) VALUES (?)");
                $query->bind_param("s", $newListName);
                $query->execute();
                echo '<script> window.location.href = "todo.php"</script>';
            }
        }
        ?>
        <form action="?mode=add_new_list" method="post">
            <input type="text" name="list_name" class="new_list" placeholder=" + Add a new list" aria-label="add a new list" />
            <button type="submit" class="btn_list" aria-label="add a new list"> +</button>

        </form>
    </div>

    <div class="tasks">
        <?php
        $query = $conn->prepare("SELECT * FROM tasks_lists WHERE task_id = ? LIMIT 1;");
        $query->bind_param("i", $task_list);
        $query->execute();
        $result = $query->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
        ?>
            <h2 id="task-list" data-task-id="<?php echo $row['task_id']; ?>" class="list_title"><?= $row['tasks_list_name'] ?></h2>
        <?php
        } else {
            // echo "Error in query: " . $conn->error;
        }
        ?>


        <div class="tasks_body">
            <div class="tasksl">
                <?php
                $query = $conn->prepare("SELECT * from tasks,tasks_lists WHERE tasks.task_list = tasks_lists.task_id AND task_list = ?;");
                $query->bind_param("i", $task_list);
                $query->execute();
                $result = $query->get_result();
                foreach ($result as $row) {
                ?>
                    <div class="task_completed">
                        <label for="<?php echo $row['task_id']; ?>"><?php echo $row['name']; ?></label>
                        <input type="checkbox" name="completed_tasks[]" onclick="taskComplete(this)" id="<?php echo $row['id']; ?>">

                        <script type="text/javascript">
                            function taskComplete(cb) {
                                if (cb.checked) {
                                    $.ajax({
                                        url: "task-complete.php",
                                        type: "POST",
                                        data: {
                                            data: cb.id
                                        },
                                        success: function() {
                                            alert('Task completed successfully!');

                                        }
                                    });
                                }
                            }
                        </script>

                        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                            $isCompleted = false;
                            if (isset($_POST['completed_tasks'])) {
                                $isCompleted = in_array($row['task_id'], $_POST['completed_tasks']);
                            }

                            if ($isCompleted) {
                                $query = $conn->prepare("UPDATE `tasks` SET `is_completed` = 1 WHERE `task_id` = ?");
                                $query->bind_param("i", $row['task_id']);
                                $query->execute();
                            }
                        } ?>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>

        <div class="add new task">
            <form action="?mode=add_new_task">
                <button class="btn_task" aria-label="add a new task"><a href="task_desc.php"> + Add a new task</a></button>

            </form>
        </div>

        <div class="delete">
            
            <button class="btn delete" id= btn_deletetask onclick="deleteCompletedTasks(this)">Delete completed tasks</button>
            <script type="text/javascript">
                function deleteCompletedTasks() {
                    $.ajax({
                        url: "task_delete.php",
                        type: "POST",
                        data: {
                            taskListId: document.getElementById("task-list").getAttribute('data-task-id')
                        },
                        success: function() {
                            alert('Completed tasks deleted successfully!');
                            location.reload();
                        }
                    });
                }
            </script>

            <button class="btn delete" id = btn_deletelist onclick="deleteList(this)">Delete List</button>
            <script type="text/javascript">
                function deleteList(btn) {
                    var taskListId = "<?php echo $task_list; ?>";

                    if (taskListId) {
                        $.ajax({
                            url: "task-list-delete.php",
                            type: "POST",
                            data: {
                                data: taskListId
                            },
                            success: function() {
                                alert('Task list deleted successfully!');
                                location.reload();
                            }
                        });
                    } else {
                        alert('No task list selected to delete!');
                    }
                }
            </script>


            <!-- <button class="btn delete">Delete List
            <!-- <?php
                    $query = $conn->prepare("Delete * from tasks_lists WHERE task_id = ? LIMIT 1;");
                    $query->bind_param("i", $task_list);
                    $query->execute();
                    ?> -->


            </button> -->
        </div>
    </div>

</body>

</html>