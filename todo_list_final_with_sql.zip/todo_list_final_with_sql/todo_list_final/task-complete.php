<?php

    $data = $_POST['data'];
    json_decode($data);


    $conn = new mysqli("localhost", "myuser", "", "todolist");
    $query = $conn->prepare("UPDATE `tasks` SET `is_completed` = 1 WHERE `id` = ?");
    $query->bind_param("i", $data);
    $query->execute();
?>