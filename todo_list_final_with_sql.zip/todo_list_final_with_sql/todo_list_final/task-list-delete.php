<?php

    $data = $_POST['data'];
    json_decode($data);


    $conn = new mysqli("localhost", "myuser", "", "todolist");
    $query = $conn->prepare("Delete from tasks_lists WHERE task_id = ? LIMIT 1;");
    // $query = $conn->prepare("Delete from tasks_lists WHERE task_id = 1 LIMIT 1;");
    $query->bind_param("i", $data);
    $query->execute();
    echo '<script> window.location.href = "todo.php"</script>';
?>
