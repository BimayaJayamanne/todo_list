<?php
$conn = new mysqli("localhost", "myuser", "", "todolist");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $taskListId = $_POST['taskListId'];

    $query = $conn->prepare("DELETE FROM tasks WHERE task_list = ? AND is_completed = 1");
    $query->bind_param("i", $taskListId);
    $query->execute();
    $query->close();
}

$conn->close();
?>
